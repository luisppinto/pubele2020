import os
def opencmd():
  os.system('terminal /k "env/Scripts/activate & set FLASK_APP=v006.py & flask run"')
opencmd()
